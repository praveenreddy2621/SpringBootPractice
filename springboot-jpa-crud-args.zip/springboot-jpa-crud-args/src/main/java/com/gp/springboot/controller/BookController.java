package com.gp.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gp.springboot.model.Book;
import com.gp.springboot.service.BookService;

@RestController
@RequestMapping("api/v1/library1")
public class BookController {
	//autowire the BookService class
	@Autowired
	BookService bookService;
	
	//creating a get mapping that retrives all the books details from the database
	@GetMapping("/getallbooks")
	private List<Book> getAllBooks(){
		return bookService.getAllBooks();
	}
	
	//creating post mapping that post the book detail in database
	@PostMapping("/addbook")
	private int saveBook(@RequestBody Book book) {
		bookService.saveBook(book);
		return book.getId();
		//book id will be sent to response body of postman after inserting book data
	}
	@PutMapping("/updatebook")
	private void updateBook(@RequestBody Book book) {
		bookService.saveBook(book);
	}
	
	 @DeleteMapping("/books/{book_id}")
	    public void deleteBook(@PathVariable int id) {
	        bookService.deleteBook(id);
	    }
	
	

}
