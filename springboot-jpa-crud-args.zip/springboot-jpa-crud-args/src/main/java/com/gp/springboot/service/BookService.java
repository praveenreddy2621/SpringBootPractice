package com.gp.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gp.springboot.model.Book;
import com.gp.springboot.repository.IBookRepository;

@Service
public class BookService {
	@Autowired
	IBookRepository booksRepository;

	// getting all the books record by using the method findAll() of CrudRepository

	public List<Book> getAllBooks() {
		List<Book> bookList;

		bookList = (List<Book>) booksRepository.findAll();
		for (Book book : bookList) {
			System.out.println(book.getName());
			System.out.println("Book with id 101 exists...? T/F " + booksRepository.existsById(101));
		}
		System.out.println("Number of rows " + booksRepository.count());
		return bookList;
	}

//getting a specific row by using the method findbyId()of CrudRepository
	public Book getBookById(int id) {
		return booksRepository.findById(id).get();
	}

	public void saveBook(Book book) {
		booksRepository.save(book);
	}

	public void updateBook(Book book) {
		booksRepository.save(book);
	}

	public void deleteBook(int id) {
		booksRepository.deleteById(id);
	}

}
