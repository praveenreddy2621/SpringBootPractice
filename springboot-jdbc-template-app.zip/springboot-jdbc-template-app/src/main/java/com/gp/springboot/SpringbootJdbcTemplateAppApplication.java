package com.gp.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJdbcTemplateAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJdbcTemplateAppApplication.class, args);
		System.out.println("Leaf Has been Started..!");
	}

}
