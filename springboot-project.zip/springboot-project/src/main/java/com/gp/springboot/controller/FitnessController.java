package com.gp.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gp.springboot.model.Payment;
import com.gp.springboot.model.Subscriber;
import com.gp.springboot.model.SubscriptionPlan;
import com.gp.springboot.model.Trainer;
import com.gp.springboot.service.PaymentService;
import com.gp.springboot.service.SubscriberService;
import com.gp.springboot.service.SubscriptionPlanService;
import com.gp.springboot.service.TrainerService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/")
public class FitnessController {

@Autowired
private SubscriberService subscriberService;

@Autowired
private PaymentService paymentService;

@Autowired
private SubscriptionPlanService subscriptionPlanService;

@Autowired
private TrainerService trainerService;

@GetMapping("/subscriber")
public List<Subscriber> getAllSubscribers() {
return subscriberService.getAllSubscribers();
}

@GetMapping("/subscriber/{id}")
public Subscriber getSubscriberById(@PathVariable Long id) {
return subscriberService.getSubscriberById(id);
}

@PostMapping("/subscriber/add")
public Subscriber addSubscriber(@Validated @RequestBody Subscriber subscriber) {
return subscriberService.addSubscriber(subscriber);
}

@PutMapping("/subscriber/edit/{id}")
public Subscriber updateSubscriber(@PathVariable Long id, @Validated @RequestBody Subscriber subscriberDetails) {
return subscriberService.updateSubscriber(id, subscriberDetails);
}

@DeleteMapping("/subscriber/delete/{id}")
public void deleteSubscriber(@PathVariable Long id) {
subscriberService.deleteSubscriber(id);
}

@GetMapping("/trainer")
public List<Trainer> getAllTrainers() {
return trainerService.getAllTrainers();
}

@GetMapping("/trainer/{id}")
public Trainer getTrainerById(@PathVariable Long id) {
return trainerService.getTrainerById(id);
}

@PostMapping("/trainer/add")
public Trainer addTrainer(@Validated @RequestBody Trainer trainer) {
return trainerService.addTrainer(trainer);
}

@PutMapping("/trainer/edit/{id}")
public Trainer updateTrainer(@PathVariable Long id, @Validated @RequestBody Trainer trainerDetails) {
return trainerService.updateTrainer(id, trainerDetails);
}

@DeleteMapping("/trainer/delete/{id}")
public void deleteTrainer(@PathVariable Long id) {
trainerService.deleteTrainer(id);
}

@GetMapping("/subscriptionplan")
public List<SubscriptionPlan> getAllSubscriptionPlans() {
return subscriptionPlanService.getAllSubscriptionPlans();
}

@GetMapping("/subscriptionplan/{plan_id}")
public SubscriptionPlan getSubscriptionPlanById(@PathVariable Long plan_id) {
return subscriptionPlanService.getSubscriptionPlanById(plan_id);
}

@PostMapping("/subscriptionplan/add")
public SubscriptionPlan addSubscriptionPlan(@Validated @RequestBody SubscriptionPlan subscriptionPlan) {
return subscriptionPlanService.addSubscriptionPlan(subscriptionPlan);
}

@PutMapping("/subscriptionplan/edit/{plan_id}")
public SubscriptionPlan updateSubscriptionPlan(@PathVariable Long plan_id, @Validated @RequestBody SubscriptionPlan subscriptionPlanDetails) {
return subscriptionPlanService.updateSubscriptionPlan(plan_id, subscriptionPlanDetails);
}

@DeleteMapping("/subscriptionplan/delete/{plan_id}")
public void deleteSubscriptionPlan(@PathVariable Long plan_id) {
subscriptionPlanService.deleteSubscriptionPlan(plan_id);
}

@GetMapping("/payment")
public List<Payment> getAllPayments() {
return paymentService.getAllPayments();
}

@GetMapping("/payment/{payment_id}")
public Payment getPaymentById(@PathVariable Long payment_id) {
return paymentService.getPaymentById(payment_id);
}

@PostMapping("/payment/add")
public Payment addPayment(@Validated @RequestBody Payment payment) {
return paymentService.addPayment(payment);
}
}
