package com.gp.springboot.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Email;

@Entity
public class Subscriber {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String fullName;
private String mobileNumber;

@Email
private String email;

private String address;

@ManyToOne
@JoinColumn(name = "subscription_plan_id")
private SubscriptionPlan subscriptionPlan;

@ManyToOne
@JoinColumn(name = "trainer_id")
private Trainer trainer;

public Long getId() {
return id;
}

public void setId(Long id) {
this.id = id;
}

public String getFullName() {
return fullName;
}

public void setFullName(String fullName) {
this.fullName = fullName;
}

public String getMobileNumber() {
return mobileNumber;
}

public void setMobileNumber(String mobileNumber) {
this.mobileNumber = mobileNumber;
}

public String getEmail() {
return email;
}

public void setEmail(String email) {
this.email = email;
}

public String getAddress() {
return address;
}

public void setAddress(String address) {
this.address = address;
}

public SubscriptionPlan getSubscriptionPlan() {
return subscriptionPlan;
}

public void setSubscriptionPlan(SubscriptionPlan subscriptionPlan) {
this.subscriptionPlan = subscriptionPlan;
}

public Trainer getTrainer() {
return trainer;
}

public void setTrainer(Trainer trainer) {
this.trainer = trainer;
}
}
