package com.gp.springboot.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gp.springboot.model.Subscriber;

public interface SubscriberRepository extends JpaRepository<Subscriber, Long> {

}

