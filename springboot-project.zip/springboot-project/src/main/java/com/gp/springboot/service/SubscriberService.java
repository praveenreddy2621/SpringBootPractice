package com.gp.springboot.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gp.springboot.model.Subscriber;
import com.gp.springboot.repository.SubscriberRepository;

@Service
public class SubscriberService {

private final SubscriberRepository subscriberRepository;

public SubscriberService(SubscriberRepository subscriberRepository) {
this.subscriberRepository = subscriberRepository;
}

public List<Subscriber> getAllSubscribers() {
return subscriberRepository.findAll();
}

public Subscriber getSubscriberById(Long id) {
return subscriberRepository.findById(id).orElse(null);
}

public Subscriber addSubscriber(Subscriber subscriber) {
return subscriberRepository.save(subscriber);
}

public Subscriber updateSubscriber(Long id, Subscriber subscriberDetails) {
Subscriber subscriber = subscriberRepository.findById(id).orElse(null);
if (subscriber != null) {
subscriber.setFullName(subscriberDetails.getFullName());
subscriber.setMobileNumber(subscriberDetails.getMobileNumber());
subscriber.setEmail(subscriberDetails.getEmail());
subscriber.setAddress(subscriberDetails.getAddress());
return subscriberRepository.save(subscriber);
}
return null;
}

public void deleteSubscriber(Long id) {
Subscriber subscriber = subscriberRepository.findById(id).orElse(null);
if (subscriber != null) {
subscriberRepository.delete(subscriber);
}}}
