package com.gp.springboot;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@ComponentScan(basePackages = "com.gp.springboot")
@EnableSwagger2
@EnableWebMvc
public class Mini4Application {

public static void main(String[] args) {
SpringApplication.run(Mini4Application.class, args);
System.out.println("App Started");
}

}
