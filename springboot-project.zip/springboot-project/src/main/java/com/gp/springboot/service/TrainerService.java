package com.gp.springboot.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gp.springboot.model.Trainer;
import com.gp.springboot.repository.TrainerRepository;

@Service
public class TrainerService {

private final TrainerRepository trainerRepository;

public TrainerService(TrainerRepository trainerRepository) {
this.trainerRepository = trainerRepository;
}

public List<Trainer> getAllTrainers() {
return trainerRepository.findAll();
}

public Trainer getTrainerById(Long id) {
return trainerRepository.findById(id).orElse(null);
}

public Trainer addTrainer(Trainer trainer) {
return trainerRepository.save(trainer);
}

public Trainer updateTrainer(Long id, Trainer trainerDetails) {
Trainer trainer = trainerRepository.findById(id).orElse(null);
if (trainer != null) {
trainer.setFullName(trainerDetails.getFullName());
trainer.setExperience(trainerDetails.getExperience());
trainer.setSpecialization(trainerDetails.getSpecialization());
return trainerRepository.save(trainer);
}
return null;
}

public void deleteTrainer(Long id) {
Trainer trainer = trainerRepository.findById(id).orElse(null);
if (trainer != null) {
trainerRepository.delete(trainer);
}
}}
