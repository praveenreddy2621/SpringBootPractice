package com.gp.springboot.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.gp.springboot.model.SubscriptionPlan;
import com.gp.springboot.repository.SubscriptionPlanRepository;

@Service
public class SubscriptionPlanService {

private final SubscriptionPlanRepository subscriptionPlanRepository;

public SubscriptionPlanService(SubscriptionPlanRepository subscriptionPlanRepository) {
this.subscriptionPlanRepository = subscriptionPlanRepository;
}

public List<SubscriptionPlan> getAllSubscriptionPlans() {
return subscriptionPlanRepository.findAll();
}

public SubscriptionPlan getSubscriptionPlanById(Long id) {
return subscriptionPlanRepository.findById(id).orElse(null);
}

public SubscriptionPlan addSubscriptionPlan(SubscriptionPlan subscriptionPlan) {
return subscriptionPlanRepository.save(subscriptionPlan);
}

public SubscriptionPlan updateSubscriptionPlan(Long id, SubscriptionPlan subscriptionPlanDetails) {
SubscriptionPlan subscriptionPlan = subscriptionPlanRepository.findById(id).orElse(null);
if (subscriptionPlan != null) {
subscriptionPlan.setPlanName(subscriptionPlanDetails.getPlanName());
subscriptionPlan.setDuration(subscriptionPlanDetails.getDuration());
subscriptionPlan.setFees(subscriptionPlanDetails.getFees());
return subscriptionPlanRepository.save(subscriptionPlan);
}
return null;
}

public void deleteSubscriptionPlan(Long id) {
SubscriptionPlan subscriptionPlan = subscriptionPlanRepository.findById(id).orElse(null);
if (subscriptionPlan != null) {
subscriptionPlanRepository.delete(subscriptionPlan);
}
}
}
