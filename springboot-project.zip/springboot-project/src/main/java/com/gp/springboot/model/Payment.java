package com.gp.springboot.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Payment {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

@ManyToOne
@JoinColumn(name = "subscriber_id")
private Subscriber subscriber;

private Double amountPaid;

@Temporal(TemporalType.DATE)
private Date paymentDate;

private String status;

public Long getId() {
return id;
}

public void setId(Long id) {
this.id = id;
}

public Subscriber getSubscriber() {
return subscriber;
}

public void setSubscriber(Subscriber subscriber) {
this.subscriber = subscriber;
}

public Double getAmountPaid() {
return amountPaid;
}

public void setAmountPaid(Double amountPaid) {
this.amountPaid = amountPaid;
}

public Date getPaymentDate() {
return paymentDate;
}

public void setPaymentDate(Date paymentDate) {
this.paymentDate = paymentDate;
}

public String getStatus() {
return status;
}

public void setStatus(String status) {
this.status = status;
}
}
