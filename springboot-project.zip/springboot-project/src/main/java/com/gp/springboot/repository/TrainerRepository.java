package com.gp.springboot.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gp.springboot.model.Trainer;

public interface TrainerRepository extends JpaRepository<Trainer, Long> {

}
