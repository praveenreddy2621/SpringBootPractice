package com.gp.springboot.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SubscriptionPlan {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private String planName;
private int duration;
private Double fees;

public Long getId() {
return id;
}

public void setId(Long id) {
this.id = id;
}

public String getPlanName() {
return planName;
}

public void setPlanName(String planName) {
this.planName = planName;
}

public int getDuration() {
return duration;
}

public void setDuration(int duration) {
this.duration = duration;
}

public Double getFees() {
return fees;
}

public void setFees(Double fees) {
this.fees = fees;
}
}
