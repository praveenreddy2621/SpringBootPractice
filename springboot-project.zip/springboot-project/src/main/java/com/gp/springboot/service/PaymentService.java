package com.gp.springboot.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gp.springboot.model.Payment;
import com.gp.springboot.repository.PaymentRepository;

@Service
public class PaymentService {

private final PaymentRepository paymentRepository;

public PaymentService(PaymentRepository paymentRepository) {
this.paymentRepository = paymentRepository;
}

public List<Payment> getAllPayments() {
return paymentRepository.findAll();
}

public Payment getPaymentById(Long id) {
return paymentRepository.findById(id).orElse(null);
}

public Payment addPayment(Payment payment) {
return paymentRepository.save(payment);
}

public Payment updatePayment(Long id, Payment paymentDetails) {
Payment payment = paymentRepository.findById(id).orElse(null);
if (payment != null) {
payment.setAmountPaid(paymentDetails.getAmountPaid());
payment.setPaymentDate(paymentDetails.getPaymentDate());
payment.setStatus(paymentDetails.getStatus());
return paymentRepository.save(payment);
}
return null;
}

public void deletePayment(Long id) {
Payment payment = paymentRepository.findById(id).orElse(null);
if (payment != null) {
paymentRepository.delete(payment);
}
}}
